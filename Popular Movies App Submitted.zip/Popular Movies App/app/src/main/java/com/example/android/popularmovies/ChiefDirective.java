package com.example.android.popularmovies;

public interface ChiefDirective {
    void executeNow();
}
